<?php
session_start();
include 'db.php';

// Kiểm tra nếu chưa đăng nhập
if (!isset($_SESSION['username'])) {
    die("<script>alert('Ngu như bò =))) mày đã đăng ký đăng nhập đâu mà đòi lấy key cu'); window.location='https://devnvios.io.vn';</script>");
}

$username = $_SESSION['username'];

// Lấy key chưa dùng (status = 0)
$sql = "SELECT key_code FROM keys_free WHERE status = 0 ORDER BY id ASC LIMIT 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($row) {
    // Tạo token bảo mật tránh copy link sang máy khác
    $_SESSION['auth_token'] = md5($username . $_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
    $_SESSION['display_key'] = trim($row['key_code']);
    $_SESSION['view_status'] = 'waiting'; // Trạng thái chờ hiển thị

    header("Location: key.php");
    exit();
} else {
    die("<script>alert('Hết key rồi cu!'); window.location='https://devnvios.io.vn';</script>");
}
?>
	