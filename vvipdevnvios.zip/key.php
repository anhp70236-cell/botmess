<?php
session_start();

$main_web = "https://devnvios.io.vn";

// 1. Kiểm tra nếu chưa đăng nhập
if (!isset($_SESSION['username'])) {
    die("<script>alert('Vui lòng đăng nhập để tiếp tục!'); window.location='$main_web';</script>");
}

// 2. Kiểm tra Token và trạng thái xem
$token = md5($_SESSION['username'] . $_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);

if (!isset($_SESSION['display_key']) || $_SESSION['auth_token'] !== $token || $_SESSION['view_status'] !== 'waiting') {
    session_destroy(); 
    header("Location: $main_web");
    exit();
}

$my_key = $_SESSION['display_key'];

// ĐÁNH DẤU ĐÃ XEM
$_SESSION['view_status'] = 'shown'; 
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Key Verification - DEVNVIOS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background-color: #0b0f1a; 
            color: #f1f5f9; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            /* ĐÃ FIX: Sử dụng 100dvh để sửa lỗi cuộn thừa trên iOS */
            min-height: 100dvh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .no-select { user-select: none; -webkit-user-select: none; }
        
        /* Card gọn gàng hơn */
        .glass-card { 
            background: #161d2f;
            border: 1px solid rgba(255, 255, 255, 0.05); 
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4); 
            width: 100%;
            max-width: 330px; 
        }
        
        /* ĐÃ FIX: Hiệu ứng tích xanh tinh tế và chuyên nghiệp hơn */
        @keyframes subtle-bounce { 
            0%, 100% { transform: scale(1); } 
            50% { transform: scale(1.04); } /* Nhịp đập nhẹ nhàng hơn */
        }
        
        .icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            /* Vòng sáng mờ chìm phía sau, không làm lóa */
            background: radial-gradient(circle, rgba(59,130,246,0.1) 0%, rgba(59,130,246,0) 70%);
            animation: subtle-bounce 3s infinite ease-in-out;
            margin-bottom: 4px;
        }

        .blue-tick {
            /* Hiệu ứng màu gradient bóng bẩy */
            background: linear-gradient(135deg, #60a5fa, #3b82f6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: inline-block;
            /* Bóng đổ tối màu để tạo chiều sâu 3D, không phát sáng */
            filter: drop-shadow(0 4px 4px rgba(0, 0, 0, 0.25));
        }

        /* Key Box đơn giản, không quá chói */
        .key-display {
            background: #0f1422;
            border: 1px dashed rgba(59, 130, 246, 0.3);
        }
    </style>
</head>
<body class="no-select" oncontextmenu="return false;">

    <div class="p-4 w-full flex justify-center">
        <div class="glass-card p-6 rounded-2xl">
            
            <div class="text-center mb-6">
                <div class="icon-wrapper">
                    <i class="fas fa-check-circle text-[54px] blue-tick"></i>
                </div>
                <h1 class="text-lg font-bold tracking-tight text-white uppercase mt-2">Lấy Key Thành Công</h1>
                <p class="text-slate-400 text-xs mt-1">Chào, <span class="text-blue-400"><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
            </div>

            <div class="key-display p-4 rounded-xl mb-6">
                <p class="text-[9px] text-slate-500 uppercase font-bold mb-2 tracking-widest text-center">Mã Key Của Bạn</p>
                <div id="keyBox" class="text-xl font-mono font-bold text-center text-blue-100 break-all">
                    <?php echo $my_key; ?>
                </div>
            </div>

            <button onclick="copyKey()" class="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-lg transition-all active:scale-95 flex items-center justify-center gap-2 text-sm shadow-lg shadow-blue-900/20">
                <i class="fas fa-copy"></i> SAO CHÉP KEY
            </button>

            <div class="mt-6 pt-4 border-t border-white/5 text-center">
                <p class="text-[10px] text-red-500/80 font-medium uppercase tracking-tighter">
                    Lưu ý: Không F5 hoặc tải lại trang để tránh mất Key
                </p>
            </div>
        </div>
    </div>

    <script>
        function copyKey() {
            const text = document.getElementById("keyBox").innerText;
            navigator.clipboard.writeText(text).then(() => {
                alert("✅ Đã sao chép Key!");
            });
        }

        // Ẩn URL thật
        if (window.history.replaceState) {
            window.history.replaceState(null, null, "xac-minh-hoan-tat");
        }

        // Chặn F12/Chuột phải
        document.onkeydown = function(e) {
            if (e.keyCode == 123 || (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0))) return false;
            if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) return false;
        };
    </script>
</body>
</html>
