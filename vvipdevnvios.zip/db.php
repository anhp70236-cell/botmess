<?php
session_start();
$conn = mysqli_connect("localhost", "wcuyntft_db", "cSmKqtBK39QVDGN3QKLc", "wcuyntft_db");
mysqli_set_charset($conn, "utf8");
$st = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM settings WHERE id=1"));
?>
	