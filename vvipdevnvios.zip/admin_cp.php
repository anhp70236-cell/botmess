<?php
include 'db.php';
session_start();

// Kiểm tra quyền Admin
$u = $_SESSION['username'] ?? '';
$user_q = mysqli_fetch_assoc(mysqli_query($conn, "SELECT role FROM users WHERE username = '$u'"));
if (($user_q['role'] ?? 0) != 1) { die("Lỗi: Quyền truy cập bị từ chối!"); }

$msg = ""; $up_dir = "uploads/";
if (!is_dir($up_dir)) mkdir($up_dir, 0777, true);

// --- 1. XỬ LÝ HỦY KEY THÀNH VIÊN (RESET SẠCH THỜI GIAN) ---
if (isset($_GET['kill_key'])) {
    mysqli_query($conn, "UPDATE users SET key_type='NONE', expiry_date=NULL WHERE id=".(int)$_GET['kill_key']." AND role!=1");
    header("Location: admin_cp.php?m=Đã xóa sạch thời gian sử dụng!");
}

// --- 2. XỬ LÝ XÓA SẢN PHẨM ---
if (isset($_GET['del_p'])) {
    $p = mysqli_fetch_assoc(mysqli_query($conn, "SELECT image FROM products WHERE id=".(int)$_GET['del_p']));
    if($p['image'] && file_exists($p['image'])) unlink($p['image']);
    mysqli_query($conn, "DELETE FROM products WHERE id=".(int)$_GET['del_p']);
    header("Location: admin_cp.php?m=Đã xóa sản phẩm!");
}

// --- 3. XỬ LÝ XÓA KEY TRONG KHO ---
if (isset($_GET['del_key'])) {
    $tbl = ($_GET['type'] == 'vip') ? 'keys_vip' : 'keys_free';
    mysqli_query($conn, "DELETE FROM $tbl WHERE id=".(int)$_GET['id']);
    header("Location: admin_cp.php?m=Đã xóa key khỏi kho!");
}

// --- 4. TẠO KEY HÀNG LOẠT (TẠO 50-100 KEY TÙY CHỈNH) ---
if (isset($_POST['gen_multi'])) {
    $type = $_POST['type']; $hr = (int)$_POST['hr']; $num = (int)$_POST['num'];
    $table = ($type == 'vip') ? 'keys_vip' : 'keys_free';
    for ($i = 0; $i < $num; $i++) {
        $code = "DEV-".strtoupper(substr(md5(uniqid()),0,8)).($type=='vip'?'-VIP':'-FREE');
        mysqli_query($conn, "INSERT INTO $table (key_code, duration_hours, status) VALUES ('$code', $hr, 0)");
    }
    $msg = "Đã tạo thành công $num Key $type!";
}

// --- 5. THÊM SẢN PHẨM ---
if (isset($_POST['add_p'])) {
    $n = mysqli_real_escape_string($conn, $_POST['p_name']); 
    $l = mysqli_real_escape_string($conn, $_POST['p_link']);
    $type = $_POST['p_type']; $img = "";
    if ($_FILES['p_img']['error'] == 0) {
        $img = $up_dir . time() . "_" . $_FILES['p_img']['name']; move_uploaded_file($_FILES['p_img']['tmp_name'], $img);
    }
    mysqli_query($conn, "INSERT INTO products (name, link, image, type) VALUES ('$n', '$l', '$img', '$type')");
    $msg = "Đã đăng sản phẩm thành công!";
}

// --- 6. CẬP NHẬT CẤU HÌNH GIAO DIỆN ---
if (isset($_POST['up_site'])) {
    foreach ($_POST['cfg'] as $k => $v) {
        $v = mysqli_real_escape_string($conn, $v);
        mysqli_query($conn, "INSERT INTO site_config (config_key, config_value) VALUES ('$k', '$v') ON DUPLICATE KEY UPDATE config_value='$v'");
    }
    if ($_FILES['site_ava']['error'] == 0) {
        $path = $up_dir . "avatar_site.png"; move_uploaded_file($_FILES['site_ava']['tmp_name'], $path);
        mysqli_query($conn, "UPDATE site_config SET config_value='$path' WHERE config_key='site_avatar'");
    }
    $msg = "Cập nhật thành công giao diện!";
}

// Lấy dữ liệu
$cf = []; $rc = mysqli_query($conn, "SELECT * FROM site_config"); while($r = mysqli_fetch_assoc($rc)) $cf[$r['config_key']] = $r['config_value'];
$list_vip = mysqli_query($conn, "SELECT * FROM keys_vip ORDER BY status ASC, id DESC");
$list_free = mysqli_query($conn, "SELECT * FROM keys_free ORDER BY status ASC, id DESC");

// Chuỗi copy key
$un_vip = ""; $qv = mysqli_query($conn, "SELECT key_code FROM keys_vip WHERE status=0"); while($rv = mysqli_fetch_assoc($qv)) $un_vip .= $rv['key_code']."\\n";
$un_free = ""; $qf = mysqli_query($conn, "SELECT key_code FROM keys_free WHERE status=0"); while($rf = mysqli_fetch_assoc($qf)) $un_free .= $rf['key_code']."\\n";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEVNVIOS - SUPER ADMIN CPANEL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f1f5f9; }
        .glass { background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); }
        .custom-scroll::-webkit-scrollbar { width: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    </style>
    <script>
        function copyText(text) {
            if(!text || text === "") return alert("Không còn key nào sạch để copy!");
            const formatText = text.replaceAll('\\n', '\n');
            navigator.clipboard.writeText(formatText);
            alert("Đã sao chép danh sách key chưa sử dụng!");
        }
    </script>
</head>
<body class="p-4 md:p-8">
    <div class="max-w-[1400px] mx-auto space-y-8">
        
        <header class="flex justify-between items-center glass p-6 rounded-[35px] shadow-sm">
            <div>
                <h1 class="text-2xl font-black text-slate-900 uppercase italic leading-none">Devnvios <span class="text-blue-600">Ultimate</span></h1>
                <p class="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">Hệ thống quản trị máy chủ v3.0</p>
            </div>
            <div class="flex items-center gap-4">
                <a href="index.php" class="bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold text-xs shadow-lg hover:bg-blue-600 transition-all">XEM TRANG CHỦ</a>
            </div>
        </header>

        <?php if($msg || isset($_GET['m'])): ?>
            <div class="bg-blue-600 text-white p-5 rounded-[25px] font-bold italic shadow-xl flex items-center gap-3">
                <i class="fas fa-check-circle"></i> <?= ($msg ?: $_GET['m']) ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <div class="lg:col-span-4 space-y-8">
                <div class="glass p-8 rounded-[40px] shadow-sm">
                    <h2 class="font-extrabold text-blue-600 uppercase italic mb-6 flex items-center gap-2 underline decoration-4 underline-offset-8">
                        <i class="fas fa-paint-roller"></i> Giao Diện & Text
                    </h2>
                    <form method="POST" enctype="multipart/form-data" class="space-y-4">
                        <div class="grid grid-cols-1 gap-4">
                            <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Logo / Domain</label>
                            <input type="text" name="cfg[logo_text]" value="<?= $cf['logo_text'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none font-bold text-xs focus:ring-2 focus:ring-blue-500"></div>
                            
                            <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Mô tả Banner</label>
                            <input type="text" name="cfg[banner_desc]" value="<?= $cf['banner_desc'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-semibold"></div>

                            <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Link Vượt Key (Bypass)</label>
                            <input type="text" name="cfg[link_bypass]" value="<?= $cf['link_bypass'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold text-blue-600"></div>

                            <div class="grid grid-cols-2 gap-3">
                                <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Text Nút</label>
                                <input type="text" name="cfg[text_kich_hoat]" value="<?= $cf['text_kich_hoat'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold"></div>
                                <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Text Xem Thêm</label>
                                <input type="text" name="cfg[text_xem_them]" value="<?= $cf['text_xem_them'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold"></div>
                            </div>

                            <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Nhóm Telegram</label>
                            <input type="text" name="cfg[link_tele_group]" value="<?= $cf['link_tele_group'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold"></div>

                            <div class="grid grid-cols-2 gap-3">
                                <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Footer By</label>
                                <input type="text" name="cfg[footer_made_by]" value="<?= $cf['footer_made_by'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold"></div>
                                <div><label class="text-[9px] font-black text-slate-400 ml-2 uppercase">Năm</label>
                                <input type="text" name="cfg[footer_year]" value="<?= $cf['footer_year'] ?>" class="w-full bg-slate-100 p-4 rounded-2xl border-none text-xs font-bold"></div>
                            </div>
                        </div>

                        <div class="p-4 bg-slate-100 rounded-3xl border-2 border-dashed border-slate-200">
                            <label class="text-[9px] font-black text-slate-400 block mb-2 uppercase">Avatar Robot (Upload mới)</label>
                            <div class="flex items-center gap-4">
                                <img src="<?= $cf['site_avatar'] ?>" class="w-12 h-12 rounded-full border-4 border-white shadow-sm bg-white">
                                <input type="file" name="site_ava" class="text-[10px] font-bold">
                            </div>
                        </div>
                        <button type="submit" name="up_site" class="w-full bg-blue-600 text-white py-4 rounded-2xl font-black uppercase text-xs shadow-xl shadow-blue-200 hover:scale-[1.02] transition-transform">Lưu Tất Cả Cấu Hình</button>
                    </form>
                </div>
            </div>

            <div class="lg:col-span-8 space-y-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-slate-900 p-8 rounded-[40px] shadow-2xl text-white relative overflow-hidden group">
                        <i class="fas fa-crown absolute -top-4 -right-4 text-amber-500/10 text-8xl transition-transform group-hover:scale-125"></i>
                        <h2 class="font-black text-amber-500 mb-6 uppercase italic flex items-center gap-2">Tạo Key VIP Hàng Loạt</h2>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="type" value="vip">
                            <div class="flex gap-2">
                                <select name="hr" class="flex-1 bg-slate-800 border-none p-4 rounded-2xl font-bold text-xs focus:ring-2 focus:ring-amber-500">
                                    <option value="720">Hạn: 30 Ngày</option>
                                    <option value="168">Hạn: 7 Ngày</option>
                                    <option value="24">Hạn: 1 Ngày</option>
                                </select>
                                <input type="number" name="num" value="50" class="w-24 bg-slate-800 border-none p-4 rounded-2xl font-bold text-xs text-center focus:ring-2 focus:ring-amber-500">
                            </div>
                            <button type="submit" name="gen_multi" class="w-full bg-amber-500 text-black font-black py-4 rounded-2xl uppercase text-xs hover:bg-white transition-colors">Xuất Bản Key VIP</button>
                        </form>
                    </div>

                    <div class="glass p-8 rounded-[40px] shadow-sm border-blue-100 relative overflow-hidden group">
                        <i class="fas fa-bolt absolute -top-4 -right-4 text-blue-500/5 text-8xl"></i>
                        <h2 class="font-black text-blue-600 mb-6 uppercase italic flex items-center gap-2">Tạo Key FREE Hàng Loạt</h2>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="type" value="free"> <input type="hidden" name="hr" value="24">
                            <div class="flex gap-2">
                                <div class="flex-1 bg-blue-50 p-4 rounded-2xl text-blue-600 font-bold text-xs flex items-center italic">Thời hạn mặc định: 24H</div>
                                <input type="number" name="num" value="50" class="w-24 bg-slate-100 border-none p-4 rounded-2xl font-bold text-xs text-center focus:ring-2 focus:ring-blue-500">
                            </div>
                            <button type="submit" name="gen_multi" class="w-full bg-blue-600 text-white font-black py-4 rounded-2xl uppercase text-xs shadow-xl shadow-blue-100 hover:bg-slate-900 transition-colors">Xuất Bản Key Free</button>
                        </form>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="glass p-8 rounded-[40px] shadow-sm h-[600px] flex flex-col border-amber-100">
                        <div class="flex justify-between items-center mb-6 border-b pb-4">
                            <h3 class="font-black text-amber-600 uppercase italic text-sm">KHO KEY VIP</h3>
                            <button onclick="copyText('<?= $un_vip ?>')" class="bg-amber-100 text-amber-700 px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-amber-600 hover:text-white transition-all">Sao Chép Key Sạch</button>
                        </div>
                        <div class="flex-1 overflow-y-auto custom-scroll space-y-3 pr-2">
                            <?php while($r=mysqli_fetch_assoc($list_vip)): ?>
                                <div class="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100 transition-all <?= $r['status']==1?'opacity-30 grayscale':'' ?>">
                                    <div class="font-mono text-[11px] font-bold"><?= $r['key_code'] ?></div>
                                    <div class="flex items-center gap-3">
                                        <span class="text-[9px] font-black uppercase <?= $r['status']==1?'text-red-500':'text-emerald-500' ?>"><?= $r['status']==1?'HẾT':'CÒN' ?></span>
                                        <a href="?del_key=1&type=vip&id=<?= $r['id'] ?>" class="text-slate-300 hover:text-red-500"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <div class="glass p-8 rounded-[40px] shadow-sm h-[600px] flex flex-col">
                        <div class="flex justify-between items-center mb-6 border-b pb-4">
                            <h3 class="font-black text-blue-600 uppercase italic text-sm">KHO KEY FREE</h3>
                            <button onclick="copyText('<?= $un_free ?>')" class="bg-blue-100 text-blue-700 px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-blue-600 hover:text-white transition-all">Sao Chép Key Sạch</button>
                        </div>
                        <div class="flex-1 overflow-y-auto custom-scroll space-y-3 pr-2">
                            <?php while($r=mysqli_fetch_assoc($list_free)): ?>
                                <div class="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100 transition-all <?= $r['status']==1?'opacity-30 grayscale':'' ?>">
                                    <div class="font-mono text-[11px] font-bold"><?= $r['key_code'] ?></div>
                                    <div class="flex items-center gap-3">
                                        <span class="text-[9px] font-black uppercase <?= $r['status']==1?'text-red-500':'text-emerald-500' ?>"><?= $r['status']==1?'HẾT':'CÒN' ?></span>
                                        <a href="?del_key=1&type=free&id=<?= $r['id'] ?>" class="text-slate-300 hover:text-red-500"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="glass p-8 rounded-[40px] shadow-sm h-[600px] flex flex-col border-emerald-100">
                    <h2 class="font-black text-emerald-600 uppercase italic mb-6 flex items-center gap-2">Thành Viên Hệ Thống</h2>
                    <div class="flex-1 overflow-y-auto custom-scroll space-y-4 pr-2">
                        <?php $us = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC"); while($r=mysqli_fetch_assoc($us)): ?>
                        <div class="bg-slate-50 p-5 rounded-3xl border border-slate-100 flex justify-between items-center">
                            <div>
                                <h4 class="font-black text-slate-800 uppercase text-xs"><?= $r['username'] ?></h4>
                                <div class="flex gap-2 mt-1">
                                    <span class="text-[9px] font-black text-blue-500 italic uppercase"><?= $r['key_type'] ?></span>
                                    <span class="text-[9px] font-bold text-slate-300"><?= $r['expiry_date'] ?: 'Không thời hạn' ?></span>
                                </div>
                            </div>
                            <?php if($r['key_type'] != 'NONE'): ?>
                                <a href="?kill_key=<?= $r['id'] ?>" onclick="return confirm('Mất sạch thời gian sử dụng?')" class="bg-red-500 text-white px-4 py-2 rounded-xl text-[9px] font-black hover:bg-slate-900 transition-colors">HỦY KEY</a>
                            <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>

                <div class="lg:col-span-2 glass p-8 rounded-[40px] shadow-sm flex flex-col border-orange-100">
                    <h2 class="font-black text-orange-600 uppercase italic mb-8 flex items-center gap-2 underline decoration-4 underline-offset-8">
                        <i class="fas fa-box-open"></i> Kho Sản Phẩm (Tools)
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 flex-1">
                        <form method="POST" enctype="multipart/form-data" class="bg-slate-900 p-8 rounded-[35px] text-white space-y-4 shadow-xl">
                            <h3 class="font-bold text-xs text-orange-400 uppercase tracking-tighter italic">Đăng Tool Mới</h3>
                            <input type="text" name="p_name" placeholder="Tên Tool..." class="w-full bg-slate-800 p-4 rounded-2xl border-none text-xs font-bold" required>
                            <input type="text" name="p_link" placeholder="Link tải file..." class="w-full bg-slate-800 p-4 rounded-2xl border-none text-xs" required>
                            <select name="p_type" class="w-full bg-slate-800 p-4 rounded-2xl border-none text-xs font-black text-orange-500">
                                <option value="FREE">HÀNG MIỄN PHÍ</option><option value="VIP">HÀNG VIP ONLY</option>
                            </select>
                            <div class="bg-slate-800 p-4 rounded-2xl border-2 border-dashed border-slate-700">
                                <input type="file" name="p_img" class="text-[9px]" required>
                            </div>
                                                        <button type="submit" name="add_p" class="w-full bg-orange-500 text-black py-4 rounded-2xl font-black uppercase text-xs hover:bg-white transition-colors">Đăng Sản Phẩm</button>
                        </form>
                        
                        <div class="grid grid-cols-2 gap-4 h-[400px] overflow-y-auto custom-scroll pr-2">
                            <?php 
                            $ps = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC"); 
                            while($r = mysqli_fetch_assoc($ps)): 
                            ?>
                            <div class="bg-white p-3 rounded-[30px] border border-slate-100 relative group shadow-sm">
                                <div class="w-full h-24 overflow-hidden rounded-[25px] mb-2 shadow-inner bg-gray-100">
                                    <?php if($r['image']): ?>
                                        <img src="<?= $r['image'] ?>" class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <div class="w-full h-full flex items-center justify-center text-[10px] text-gray-400">No Img</div>
                                    <?php endif; ?>
                                </div>
                                
                                <p class="font-black text-[10px] uppercase truncate px-2 text-slate-700"><?= $r['name'] ?></p>
                                <div class="flex justify-between items-center px-2 mt-1">
                                    <span class="text-[8px] font-bold <?= $r['type']=='VIP'?'text-amber-500':'text-blue-500' ?> italic uppercase"><?= $r['type'] ?></span>
                                    <a href="?del_p=<?= $r['id'] ?>" onclick="return confirm('Xác nhận xóa Tool này và ảnh liên quan?')" class="text-red-400 hover:text-red-600 transition-colors">
                                        <i class="fas fa-trash-alt text-[10px]"></i>
                                    </a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div> </div> <footer class="text-center py-10">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                &copy; <?= $cf['footer_year'] ?> <?= $cf['footer_made_by'] ?> - TRANG QUẢN TRỊ CAO CẤP
            </p>
        </footer>

    </div> <script>
        // Tự động ẩn thông báo sau 3 giây
        setTimeout(() => {
            const msg = document.querySelector('.bg-blue-600.text-white');
            if(msg) msg.style.display = 'none';
        }, 3000);
    </script>
</body>
</html>
