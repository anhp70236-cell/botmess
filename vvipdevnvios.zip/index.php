<?php 
include 'db.php'; 
session_start(); 

// --- Tự động xóa key khi hết hạn ---
if(isset($_SESSION['username'])){
    $u_check = $_SESSION['username'];
    mysqli_query($conn, "UPDATE users SET key_type = 'NONE', expiry_date = NULL WHERE username = '$u_check' AND expiry_date <= NOW() AND role != 1");
}

$configs = [];
$res_config = mysqli_query($conn, "SELECT * FROM site_config");
if($res_config) {
    while($c = mysqli_fetch_assoc($res_config)) { 
        $configs[$c['config_key']] = $c['config_value']; 
    }
}

$logo_text = $configs['logo_text'] ?? 'DEVNVIOS.io.vn';
$chao_khach = $configs['chao_khach'] ?? 'Hi!';
$banner_title = $configs['banner_title'] ?? 'DEVNVIOS.CO';
$banner_desc = $configs['banner_desc'] ?? 'Tiện ích tool hỗ trợ & automation';
$footer_made_by = $configs['footer_made_by'] ?? 'DEVNVIOS';
$footer_year = $configs['footer_year'] ?? '@2024';
$link_group_tele = $configs['link_tele_group'] ?? 'https://t.me/crackpythonva';
$site_avatar = $configs['site_avatar'] ?? '';

$link_admin_tele = "https://t.me/iosnea";
$link_bypass = $configs['link_bypass'] ?? "#";
$products_list = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");

$is_admin = false;
$is_logged_in = isset($_SESSION['username']);
$time_left = 0;
$user_key_type = "Thành viên";
$expiry_timestamp = 0; 

if($is_logged_in){
    $u = $_SESSION['username'];
    $user_q = mysqli_fetch_assoc(mysqli_query($conn, "SELECT role, key_type, expiry_date FROM users WHERE username = '$u'"));
    if(($user_q['role'] ?? 0) == 1) $is_admin = true;
    
    $user_key_type_raw = $user_q['key_type'] ?? 'NONE';
    if($user_key_type_raw == 'FREE') $user_key_type = "Free";
    if($user_key_type_raw == 'VIP') $user_key_type = "Vip";
    
    if(!empty($user_q['expiry_date'])) {
        $expiry_timestamp = strtotime($user_q['expiry_date']); 
        $now = time(); 
        $time_left = $expiry_timestamp - $now;
        if($time_left < 0) $time_left = 0;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!$is_logged_in) { header("Location: ?status=not_logged_in"); exit(); }
    $status = "key_wrong";
    $u = $_SESSION['username'];
    if (isset($_POST['submit_vip'])) {
        $key_vip = mysqli_real_escape_string($conn, $_POST['key_vip']);
        $check = mysqli_query($conn, "SELECT * FROM keys_vip WHERE key_code = '$key_vip' AND status = 0 LIMIT 1");
        if ($row = mysqli_fetch_assoc($check)) {
            $hr = $row['duration_hours'];
            mysqli_query($conn, "UPDATE keys_vip SET status = 1 WHERE key_code = '$key_vip'");
            mysqli_query($conn, "UPDATE users SET key_type = 'VIP', expiry_date = DATE_ADD(NOW(), INTERVAL $hr HOUR) WHERE username = '$u'");
            $status = "success";
        }
    } 
    elseif (isset($_POST['submit_free'])) {
        $key_free = mysqli_real_escape_string($conn, $_POST['key_free']);
        $check = mysqli_query($conn, "SELECT * FROM keys_free WHERE key_code = '$key_free' AND status = 0 LIMIT 1");
        if ($row = mysqli_fetch_assoc($check)) {
            $hr = $row['duration_hours'] ?? 24;
            mysqli_query($conn, "UPDATE keys_free SET status = 1 WHERE key_code = '$key_free'");
            mysqli_query($conn, "UPDATE users SET key_type = 'FREE', expiry_date = DATE_ADD(NOW(), INTERVAL $hr HOUR) WHERE username = '$u'");
            $status = "success";
        }
    }
    header("Location: ?status=" . $status);
    exit();
}
$status_msg = $_GET['status'] ?? "";
?>
<!DOCTYPE html>
<html lang="vi" style="scroll-behavior: smooth;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, viewport-fit=cover">
    
    <title><?php echo $logo_text; ?></title>
    <meta name="description" content="<?php echo $banner_desc; ?>">
    <meta property="og:title" content="<?php echo $logo_text; ?>">
    <meta property="og:description" content="<?php echo $banner_desc; ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?php echo $site_avatar; ?>">

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --ios-safe-bottom: env(safe-area-inset-bottom); }
        body { 
            background: #f4f6f9; font-family: sans-serif; -webkit-tap-highlight-color: transparent; 
            overflow-x: hidden; 
            margin: 0; padding: 0;
        }
        
        .header-top { background: #1a2b3c; height: 50px; padding: 0 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: relative; z-index: 1001; }
        
        /* Chữ logo: Nghiêng nhẹ, In đậm cực hạn */
        .logo-custom { 
            font-size: 19px; 
            font-weight: 900; 
            color: #3498db; 
            text-decoration: none;
            display: inline-block; 
            letter-spacing: -0.5px; 
            cursor: pointer; 
            line-height: 1;
            transform: skewX(-6deg); /* Giảm độ nghiêng theo ý bạn */
        }
        
        .chu-meo-thang { display: inline-block; letter-spacing: -0.5px; line-height: 1.2; }
        
        /* ĐÃ FIX: Giảm độ nghiêng từ -12deg xuống -5deg để nghiêng nhẹ nhàng hơn */
        .chu-meo-nghieng { 
            display: inline-block; 
            transform: skewX(-5deg); 
            font-size: 11px; 
            letter-spacing: -0.3px; 
            line-height: 1.2; 
        }

        .auth-login { color: #555; font-weight: 800; font-size: 10px; text-transform: uppercase; cursor: pointer; }
        .auth-register { color: #007bff; font-weight: 800; font-size: 10px; text-transform: uppercase; cursor: pointer; }

        #menu-content { 
            max-height: 0; overflow: hidden; opacity: 0; 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
            position: absolute; right: 10px; top: 50px; background: white; border-radius: 8px; width: 230px; 
            z-index: 9999; border: 1px solid #eee; box-shadow: 0 10px 25px rgba(0,0,0,0.2); visibility: hidden;
            transform: translateY(-20px); 
        }
        #menu-content.show { max-height: 80vh; opacity: 1; padding: 5px 0; visibility: visible; transform: translateY(0); }
        
        .menu-link-small { display: block; padding: 10px 15px; font-size: 10px; font-weight: bold; text-transform: uppercase; color: #666; border-bottom: 1px solid #f5f5f5; cursor: pointer; }
        .tool-nav-item { display: flex; align-items: center; padding: 10px 15px; gap: 10px; border-bottom: 1px solid #f1f1f1; cursor: pointer; }
        .tool-nav-item img { width: 24px; height: 24px; border-radius: 5px; object-fit: cover; }
        .tool-nav-item span { font-size: 11px; font-weight: bold; color: #333; text-transform: uppercase; }

        .card-ios { background: #fff; border-radius: 4px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 10px; border-bottom: 1px solid #ddd; }
        
        .input-key { 
            border: 1px solid #ddd; padding: 8px 12px; border-radius: 4px; width: 100%; 
            margin-top: 5px; font-size: 16px; outline: none; transition: border-color 0.3s;
            height: 40px; box-sizing: border-box;
        }
        .input-key:focus { border-color: #007bff; }
        .btn-act { background: #007bff; color: white; font-weight: bold; padding: 8px 15px; border-radius: 4px; text-transform: uppercase; font-size: 11px; cursor: pointer; border: none; height: 36px; }
        
        .heart-beat { color: #ff3b30; animation: beat 0.6s infinite; display: inline-block; font-size: 13px; vertical-align: middle; }
        @keyframes beat { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
        
        .footer-year { color: #9ca3af; font-size: 11px; display: block; margin-top: 3px; font-weight: normal; }

        #menu-overlay { 
            position: fixed; inset: 0; background: rgba(0,0,0,0.05); z-index: 999; 
            opacity: 0; visibility: hidden; transition: all 0.3s ease; 
        }
        #menu-overlay.show { opacity: 1; visibility: visible; }

        @keyframes logoPop {
            0% { transform: scale(0); opacity: 0; }
            80% { transform: scale(1.1); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }
        .logo-load-smooth { animation: logoPop 0.5s ease-out forwards; }
    </style>
</head>
<body class="min-h-[100dvh] flex flex-col">
    <div id="menu-overlay" onclick="closeMenu()"></div>

    <header id="main-header" class="header-top flex justify-between items-center text-white">
        <div onclick="_go('Lw==')" class="logo-custom"><?php echo $logo_text; ?></div>
        
        <button id="menu-btn" onclick="toggleMenu(event)" class="text-xl p-1 focus:outline-none flex items-center justify-center h-full"><i class="fas fa-bars"></i></button>
        
        <div id="menu-content">
            <div onclick="_go('Lw=='); closeMenu();" class="menu-link-small"><i class="fas fa-home mr-2 text-blue-500"></i> Trang Chủ</div>
            <div class="bg-gray-50 px-4 py-1 text-[9px] font-bold text-gray-400 uppercase tracking-tighter">Danh sách Tool</div>
            
            <?php 
            mysqli_data_seek($products_list, 0); 
            while($tool = mysqli_fetch_assoc($products_list)): 
                $t_name = $tool['name']; $t_link = $tool['link']; $t_type = strtoupper($tool['type'] ?? 'FREE');
            ?>
                <div onclick="checkToolAccess('<?php echo $t_link; ?>', <?php echo ($t_type == 'VIP' ? 'true' : 'false'); ?>); closeMenu();" class="tool-nav-item">
                    <img src="<?php echo $tool['image']; ?>" onerror="this.src='https://cdn-icons-png.flaticon.com/512/2589/2589174.png'">
                    <span><?php echo $t_name; ?> (<?php echo $t_type; ?>)</span>
                </div>
            <?php endwhile; ?>

            <?php if($is_admin): ?> 
                <div onclick="_go('YWRtaW5fY3A='); closeMenu();" class="menu-link-small text-red-600">Admin Cpanel</div> 
            <?php endif; ?>
            <?php if($is_logged_in): ?> 
                <div onclick="_go('bG9nb3V0'); closeMenu();" class="menu-link-small text-gray-400">Đăng Xuất</div> 
            <?php endif; ?>
        </div>
    </header>

    <div class="bg-white border-b py-3 px-4 flex justify-between items-center shadow-sm relative z-[998]">
        <div class="text-[9px] font-bold italic text-gray-500 uppercase">
            <?php if($is_logged_in): ?> 
                Hi, <span class="text-blue-600"><?php echo $_SESSION['username']; ?></span> 
                | <span class="text-orange-500"><?php echo $user_key_type; ?></span> 
                | <span id="main_timer" class="font-mono text-red-500">00:00:00</span>
            <?php else: ?> 
                <?php echo $chao_khach; ?> 
            <?php endif; ?>
        </div>
        <div class="flex gap-4">
            <?php if(!$is_logged_in): ?> 
                <div onclick="_go('ZGFuZy1uaGFw')" class="auth-login">Đăng Nhập</div> 
                <div onclick="_go('ZGFuZy1reQ==')" class="auth-register">Đăng Ký</div> 
            <?php endif; ?>
        </div>
    </div>

    <main class="max-w-xl mx-auto p-4 w-full flex-grow">
        
        <?php if($status_msg == "success"): ?>
            <div id="status-alert" class="card-ios bg-green-50 text-green-600 text-center font-bold text-xs p-3 mb-3 rounded border-green-200 border">Kích hoạt Key thành công!</div>
        <?php elseif($status_msg == "key_wrong"): ?>
            <div id="status-alert" class="card-ios bg-red-50 text-red-600 text-center font-bold text-xs p-3 mb-3 rounded border-red-200 border">Key sai hoặc đã có người sử dụng!</div>
        <?php elseif($status_msg == "not_logged_in"): ?>
            <div id="status-alert" class="card-ios bg-orange-50 text-orange-600 text-center font-bold text-xs p-3 mb-3 rounded border-orange-200 border">Vui lòng Đăng Nhập để thực hiện!</div>
        <?php endif; ?>

        <div class="bg-[#10b981] rounded-lg py-1 px-3 text-white flex items-center gap-4 mb-2 shadow-sm relative z-10">
            <div class="w-20 h-20 flex items-center justify-center shrink-0 logo-load-smooth bg-transparent border-none shadow-none">
                <?php if(!empty($site_avatar)): ?> 
                    <img src="<?php echo $site_avatar; ?>" class="w-full h-full object-contain"> 
                <?php else: ?> 
                    <i class="fas fa-robot text-[65px] text-white"></i> 
                <?php endif; ?>
            </div>
            <div class="flex-grow">
                <h2 class="text-xl font-black uppercase chu-meo-thang"><?php echo $banner_title; ?></h2>
                <p class="opacity-95 chu-meo-nghieng"><?php echo $banner_desc; ?></p>
            </div>
        </div>

        <div class="text-center py-2">
            <a href="<?php echo $link_group_tele; ?>" target="_blank" class="text-red-500 font-extrabold text-[12px] uppercase chu-meo-nghieng underline decoration-red-500 underline-offset-2">Tham gia nhóm telegram</a>
        </div>

        <div class="card-ios">
            <h3 class="text-red-600 font-bold uppercase text-[11px] border-b-2 border-red-500 w-fit pb-1 mb-3 chu-meo-thang">Key Vip</h3>
            <form action="" method="POST">
                <input type="text" name="key_vip" class="input-key" placeholder="Nhập Key VIP..." required>
                <div class="flex justify-between items-center mt-3">
                    <button type="button" onclick="toggleNL('nl-vip')" class="text-blue-600 text-[10px] font-bold uppercase">Xem thêm</button>
                    <button type="submit" name="submit_vip" class="btn-act">Kích Hoạt</button>
                </div>
            </form>
            <div id="nl-vip" style="display:none;" class="mt-4 p-3 bg-blue-50 rounded text-xs text-gray-700 italic border border-blue-100">
                Mua key vip liên hệ <a href="https://t.me/iosnea" target="_blank" class="text-[#0088cc] font-bold inline-flex items-center gap-1 underline">Telegram <i class="fab fa-telegram"></i></a>
            </div>
        </div>

        <div class="card-ios mt-4">
            <h3 class="text-gray-600 font-bold uppercase text-[11px] border-b-2 border-gray-500 w-fit pb-1 mb-3 chu-meo-thang">Key Free</h3>
            <form action="" method="POST">
                <input type="text" name="key_free" class="input-key" placeholder="Nhập Key Free..." required>
                <div class="flex justify-between items-center mt-3">
                    <button type="button" onclick="toggleNL('nl-free')" class="text-blue-600 text-[10px] font-bold uppercase">Xem thêm</button>
                    <button type="submit" name="submit_free" class="btn-act !bg-gray-600">Kích Hoạt</button>
                </div>
            </form>
            <div id="nl-free" style="display:none;" class="mt-3 text-center">
                <a href="<?php echo $link_bypass; ?>" target="_blank" class="text-orange-500 text-[11px] font-bold underline italic uppercase">Lấy Key Miễn Phí Tại Đây</a>
            </div>
        </div>
    </main>

    <footer class="py-2 text-center bg-white border-t">
        <div class="uppercase font-bold text-gray-600 pb-[var(--ios-safe-bottom)] text-[11px]">
            MADE WITH <span class="heart-beat"><i class="fas fa-heart"></i></span> BY <div onclick="_go('Lw==')" class="inline text-blue-600 cursor-pointer"><?php echo $footer_made_by; ?></div>
            <span class="footer-year"><?php echo $footer_year; ?></span>
        </div>
    </footer>

    <script>
        const _go = (x) => window.location.href = window.location.origin + (atob(x).startsWith('/') ? atob(x) : '/' + atob(x));
        const userKeyType = "<?php echo $user_key_type; ?>";
        const isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;

        function checkToolAccess(link, isVipTool) {
            if (!isLoggedIn) { alert("Bạn cần đăng nhập!"); return; }
            if (isVipTool && userKeyType !== "Vip") { alert("Chỉ dành cho VIP!"); }
            else if (userKeyType === "Thành viên") { alert("Vui lòng nhập Key!"); }
            else { window.location.href = link; }
        }

        const serverExpiry = <?php echo $expiry_timestamp; ?> * 1000;
        function updateTimer() {
            const display = document.getElementById('main_timer');
            if(!display) return;
            const now = Date.now();
            const diff = Math.floor((serverExpiry - now) / 1000);
            if(diff <= 0) { display.innerHTML = "00:00:00"; return; }
            let h = Math.floor(diff / 3600);
            let m = Math.floor((diff % 3600) / 60);
            let s = diff % 60;
            display.innerHTML = (h<10?'0':'')+h + ":" + (m<10?'0':'')+m + ":" + (s<10?'0':'')+s;
        }
        if(serverExpiry > 0) { setInterval(updateTimer, 1000); updateTimer(); }

        if (window.history.replaceState) { window.history.replaceState(null, null, window.location.pathname); }
        setTimeout(() => {
            const alertBox = document.getElementById('status-alert');
            if(alertBox) {
                alertBox.style.transition = "opacity 0.5s ease";
                alertBox.style.opacity = "0";
                setTimeout(() => alertBox.style.display = "none", 500);
            }
        }, 3000);

        const menuContent = document.getElementById('menu-content');
        const menuOverlay = document.getElementById('menu-overlay');

        function toggleMenu(e) { 
            e.stopPropagation(); 
            if(menuContent.classList.contains('show')) closeMenu();
            else openMenu();
        }
        function openMenu() { menuContent.classList.add('show'); menuOverlay.classList.add('show'); }
        function closeMenu() { menuContent.classList.remove('show'); menuOverlay.classList.remove('show'); }
        function toggleNL(id) { const x = document.getElementById(id); x.style.display = (x.style.display === 'block') ? 'none' : 'block'; }

        window.addEventListener('scroll', () => { if(menuContent.classList.contains('show')) closeMenu(); }, { passive: true });
        document.addEventListener('touchstart', (e) => {
            if (!menuContent.contains(e.target) && !document.getElementById('menu-btn').contains(e.target)) closeMenu();
        }, { passive: true });
    </script>
</body>
</html>
