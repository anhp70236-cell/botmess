-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th4 21, 2026 lúc 05:14 AM
-- Phiên bản máy phục vụ: 5.7.41-cll-lve
-- Phiên bản PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `wcuyntft_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `keys_free`
--

CREATE TABLE `keys_free` (
  `id` int(11) NOT NULL,
  `key_code` varchar(100) NOT NULL,
  `duration_hours` int(11) DEFAULT '24',
  `status` int(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `keys_free`
--

INSERT INTO `keys_free` (`id`, `key_code`, `duration_hours`, `status`, `created_at`) VALUES
(1, 'DEV-1EA2690D-FREE', 24, 0, '2026-04-17 01:12:03'),
(2, 'DEV-BD86B6AA-FREE', 24, 0, '2026-04-17 01:12:03'),
(3, 'DEV-531655A6-FREE', 24, 0, '2026-04-17 01:12:03'),
(4, 'DEV-9E9064DD-FREE', 24, 0, '2026-04-17 01:12:03'),
(5, 'DEV-46248185-FREE', 24, 1, '2026-04-17 01:12:03'),
(6, 'DEV-84F4F434-FREE', 24, 0, '2026-04-17 01:12:03'),
(7, 'DEV-CD804DDE-FREE', 24, 0, '2026-04-17 01:12:03'),
(8, 'DEV-8525B6E2-FREE', 24, 0, '2026-04-17 01:12:03'),
(9, 'DEV-5B065BE0-FREE', 24, 0, '2026-04-17 01:12:03'),
(10, 'DEV-A97C3D6D-FREE', 24, 0, '2026-04-17 01:12:03'),
(11, 'DEV-999FC337-FREE', 24, 0, '2026-04-17 01:12:03'),
(12, 'DEV-29C316EC-FREE', 24, 0, '2026-04-17 01:12:03'),
(13, 'DEV-9F2B8098-FREE', 24, 0, '2026-04-17 01:12:03'),
(14, 'DEV-916A5C6B-FREE', 24, 0, '2026-04-17 01:12:03'),
(15, 'DEV-44A18193-FREE', 24, 0, '2026-04-17 01:12:03'),
(16, 'DEV-80BB95DF-FREE', 24, 0, '2026-04-17 01:12:03'),
(17, 'DEV-774847CB-FREE', 24, 0, '2026-04-17 01:12:03'),
(18, 'DEV-FE53B4ED-FREE', 24, 0, '2026-04-17 01:12:03'),
(19, 'DEV-9B61E6F6-FREE', 24, 0, '2026-04-17 01:12:03'),
(20, 'DEV-AE274E9C-FREE', 24, 0, '2026-04-17 01:12:03'),
(21, 'DEV-092A0582-FREE', 24, 0, '2026-04-17 01:12:03'),
(22, 'DEV-1F65A435-FREE', 24, 0, '2026-04-17 01:12:03'),
(23, 'DEV-8B91D7E1-FREE', 24, 0, '2026-04-17 01:12:03'),
(24, 'DEV-2D2BAE82-FREE', 24, 0, '2026-04-17 01:12:03'),
(25, 'DEV-F6EBC47A-FREE', 24, 0, '2026-04-17 01:12:03'),
(26, 'DEV-3F4B71BE-FREE', 24, 0, '2026-04-17 01:12:03'),
(27, 'DEV-A99CF3D4-FREE', 24, 0, '2026-04-17 01:12:03'),
(28, 'DEV-2D1DE567-FREE', 24, 0, '2026-04-17 01:12:03'),
(29, 'DEV-0DD76065-FREE', 24, 0, '2026-04-17 01:12:03'),
(30, 'DEV-ACD72B32-FREE', 24, 0, '2026-04-17 01:12:03'),
(31, 'DEV-8E467B77-FREE', 24, 0, '2026-04-17 01:12:03'),
(32, 'DEV-ED5698B7-FREE', 24, 0, '2026-04-17 01:12:03'),
(33, 'DEV-361A9A1E-FREE', 24, 0, '2026-04-17 01:12:03'),
(34, 'DEV-FD22F654-FREE', 24, 0, '2026-04-17 01:12:03'),
(35, 'DEV-B6E8FF3B-FREE', 24, 0, '2026-04-17 01:12:03'),
(36, 'DEV-F1CCA9F1-FREE', 24, 0, '2026-04-17 01:12:03'),
(37, 'DEV-9B25A66B-FREE', 24, 0, '2026-04-17 01:12:03'),
(38, 'DEV-16E72BB0-FREE', 24, 0, '2026-04-17 01:12:03'),
(39, 'DEV-171C1A00-FREE', 24, 0, '2026-04-17 01:12:03'),
(40, 'DEV-58D03474-FREE', 24, 0, '2026-04-17 01:12:03'),
(41, 'DEV-BB528255-FREE', 24, 0, '2026-04-17 01:12:03'),
(42, 'DEV-D254F89A-FREE', 24, 0, '2026-04-17 01:12:03'),
(43, 'DEV-3C807103-FREE', 24, 0, '2026-04-17 01:12:03'),
(44, 'DEV-34A17117-FREE', 24, 0, '2026-04-17 01:12:03'),
(45, 'DEV-84BF2A19-FREE', 24, 1, '2026-04-17 01:12:03'),
(46, 'DEV-3E392EB1-FREE', 24, 0, '2026-04-17 01:12:03'),
(47, 'DEV-EFED949B-FREE', 24, 0, '2026-04-17 01:12:03'),
(48, 'DEV-CAD6D866-FREE', 24, 0, '2026-04-17 01:12:03'),
(49, 'DEV-3D2ECA46-FREE', 24, 1, '2026-04-17 01:12:03'),
(50, 'DEV-2E549B72-FREE', 24, 0, '2026-04-17 01:12:03'),
(51, 'DEV-249A7565-FREE', 24, 0, '2026-04-17 01:12:43'),
(52, 'DEV-4FA5FD31-FREE', 24, 0, '2026-04-17 01:12:43'),
(53, 'DEV-4677A519-FREE', 24, 0, '2026-04-17 01:12:43'),
(54, 'DEV-903505D4-FREE', 24, 0, '2026-04-17 01:12:43'),
(55, 'DEV-43887955-FREE', 24, 0, '2026-04-17 01:12:43'),
(56, 'DEV-E123C6D2-FREE', 24, 0, '2026-04-17 01:12:43'),
(57, 'DEV-E86631C4-FREE', 24, 0, '2026-04-17 01:12:43'),
(58, 'DEV-3E785C9D-FREE', 24, 0, '2026-04-17 01:12:43'),
(59, 'DEV-B5FF12E0-FREE', 24, 0, '2026-04-17 01:12:43'),
(60, 'DEV-D7EC8C78-FREE', 24, 0, '2026-04-17 01:12:43'),
(61, 'DEV-E53398A3-FREE', 24, 0, '2026-04-17 01:12:43'),
(62, 'DEV-B486B738-FREE', 24, 0, '2026-04-17 01:12:43'),
(63, 'DEV-877C2EED-FREE', 24, 0, '2026-04-17 01:12:43'),
(64, 'DEV-2355CB98-FREE', 24, 0, '2026-04-17 01:12:43'),
(65, 'DEV-B88DA9D0-FREE', 24, 0, '2026-04-17 01:12:43'),
(66, 'DEV-A627B692-FREE', 24, 0, '2026-04-17 01:12:43'),
(67, 'DEV-96E29778-FREE', 24, 0, '2026-04-17 01:12:43'),
(68, 'DEV-0482A014-FREE', 24, 0, '2026-04-17 01:12:43'),
(69, 'DEV-C8468396-FREE', 24, 0, '2026-04-17 01:12:43'),
(70, 'DEV-D1911CF2-FREE', 24, 0, '2026-04-17 01:12:43'),
(71, 'DEV-E57861FB-FREE', 24, 0, '2026-04-17 01:12:43'),
(72, 'DEV-0386019F-FREE', 24, 0, '2026-04-17 01:12:43'),
(73, 'DEV-FB7903D0-FREE', 24, 0, '2026-04-17 01:12:43'),
(74, 'DEV-D21A1FB7-FREE', 24, 0, '2026-04-17 01:12:43'),
(75, 'DEV-A6846812-FREE', 24, 0, '2026-04-17 01:12:43'),
(76, 'DEV-A634A9AE-FREE', 24, 0, '2026-04-17 01:12:43'),
(77, 'DEV-D04CBC1A-FREE', 24, 0, '2026-04-17 01:12:43'),
(78, 'DEV-CB661DBD-FREE', 24, 0, '2026-04-17 01:12:43'),
(79, 'DEV-13EAC6E5-FREE', 24, 0, '2026-04-17 01:12:43'),
(80, 'DEV-21A68336-FREE', 24, 0, '2026-04-17 01:12:43'),
(81, 'DEV-32AB2848-FREE', 24, 0, '2026-04-17 01:12:43'),
(82, 'DEV-F0FE27FA-FREE', 24, 0, '2026-04-17 01:12:43'),
(83, 'DEV-8C28EEB5-FREE', 24, 0, '2026-04-17 01:12:43'),
(84, 'DEV-D267A634-FREE', 24, 0, '2026-04-17 01:12:43'),
(85, 'DEV-AC0594DC-FREE', 24, 0, '2026-04-17 01:12:43'),
(86, 'DEV-E58DA4AD-FREE', 24, 0, '2026-04-17 01:12:43'),
(87, 'DEV-5E0DD686-FREE', 24, 0, '2026-04-17 01:12:43'),
(88, 'DEV-9EF18EB1-FREE', 24, 0, '2026-04-17 01:12:43'),
(89, 'DEV-CD778FCD-FREE', 24, 0, '2026-04-17 01:12:43'),
(90, 'DEV-CA39455B-FREE', 24, 1, '2026-04-17 01:12:43'),
(91, 'DEV-E8A54B4E-FREE', 24, 0, '2026-04-17 01:12:43'),
(92, 'DEV-D211D099-FREE', 24, 1, '2026-04-17 01:12:43'),
(93, 'DEV-07A9F450-FREE', 24, 0, '2026-04-17 01:12:43'),
(94, 'DEV-B8AFFD27-FREE', 24, 0, '2026-04-17 01:12:43'),
(95, 'DEV-BD30098F-FREE', 24, 1, '2026-04-17 01:12:43'),
(96, 'DEV-B8BFAF58-FREE', 24, 1, '2026-04-17 01:12:43'),
(97, 'DEV-A9459192-FREE', 24, 1, '2026-04-17 01:12:43'),
(98, 'DEV-B23B9244-FREE', 24, 1, '2026-04-17 01:12:43'),
(99, 'DEV-51D2AE5D-FREE', 24, 1, '2026-04-17 01:12:43'),
(100, 'DEV-EC2241B1-FREE', 24, 1, '2026-04-17 01:12:43'),
(101, 'DEV-47117C98-FREE', 24, 1, '2026-04-17 02:42:56'),
(102, 'DEV-90209D78-FREE', 24, 1, '2026-04-17 22:39:19'),
(103, 'DEV-F67047E9-FREE', 24, 1, '2026-04-19 19:14:56');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `keys_vip`
--

CREATE TABLE `keys_vip` (
  `id` int(11) NOT NULL,
  `key_code` varchar(100) NOT NULL,
  `duration_hours` int(11) NOT NULL,
  `status` int(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `keys_vip`
--

INSERT INTO `keys_vip` (`id`, `key_code`, `duration_hours`, `status`, `created_at`) VALUES
(1, 'DEV-8D13C682-VIP', 720, 0, '2026-04-17 01:50:51'),
(2, 'DEV-A05185BA-VIP', 720, 0, '2026-04-17 01:50:51'),
(3, 'DEV-A53C92AB-VIP', 720, 0, '2026-04-17 01:50:51'),
(4, 'DEV-85323CA6-VIP', 720, 0, '2026-04-17 01:50:51'),
(5, 'DEV-1DD12917-VIP', 720, 0, '2026-04-17 01:50:51'),
(6, 'DEV-1418FFDE-VIP', 720, 0, '2026-04-17 01:50:51'),
(7, 'DEV-473A93CB-VIP', 720, 0, '2026-04-17 01:50:51'),
(8, 'DEV-1FCA70EF-VIP', 720, 0, '2026-04-17 01:50:51'),
(9, 'DEV-DD2EA475-VIP', 720, 0, '2026-04-17 01:50:51'),
(10, 'DEV-5850D366-VIP', 720, 0, '2026-04-17 01:50:51'),
(11, 'DEV-5EC41F20-VIP', 720, 0, '2026-04-17 01:50:51'),
(12, 'DEV-9AEDB3AA-VIP', 720, 0, '2026-04-17 01:50:51'),
(13, 'DEV-3F04F36D-VIP', 720, 0, '2026-04-17 01:50:51'),
(14, 'DEV-7D0497E7-VIP', 720, 0, '2026-04-17 01:50:51'),
(15, 'DEV-DA965A53-VIP', 720, 0, '2026-04-17 01:50:51'),
(16, 'DEV-0E696027-VIP', 720, 0, '2026-04-17 01:50:51'),
(17, 'DEV-F4C04355-VIP', 720, 0, '2026-04-17 01:50:51'),
(18, 'DEV-084EEBC7-VIP', 720, 0, '2026-04-17 01:50:51'),
(19, 'DEV-D67EBAC6-VIP', 720, 0, '2026-04-17 01:50:51'),
(20, 'DEV-1A94D374-VIP', 720, 0, '2026-04-17 01:50:51'),
(21, 'DEV-AAA66F01-VIP', 720, 0, '2026-04-17 01:50:51'),
(22, 'DEV-067A3411-VIP', 720, 0, '2026-04-17 01:50:51'),
(23, 'DEV-74BB6FAF-VIP', 720, 0, '2026-04-17 01:50:51'),
(24, 'DEV-EC1D52A7-VIP', 720, 0, '2026-04-17 01:50:51'),
(25, 'DEV-3B90E4AE-VIP', 720, 0, '2026-04-17 01:50:51'),
(26, 'DEV-364E3BF7-VIP', 720, 0, '2026-04-17 01:50:51'),
(27, 'DEV-0584A08F-VIP', 720, 0, '2026-04-17 01:50:51'),
(28, 'DEV-4BD8C289-VIP', 720, 0, '2026-04-17 01:50:51'),
(29, 'DEV-B96A19CA-VIP', 720, 0, '2026-04-17 01:50:51'),
(30, 'DEV-3604843A-VIP', 720, 0, '2026-04-17 01:50:51'),
(31, 'DEV-0E61C9DC-VIP', 720, 0, '2026-04-17 01:50:51'),
(32, 'DEV-7D30D48A-VIP', 720, 0, '2026-04-17 01:50:51'),
(33, 'DEV-95BF02A6-VIP', 720, 0, '2026-04-17 01:50:51'),
(34, 'DEV-BFC12A08-VIP', 720, 0, '2026-04-17 01:50:51'),
(35, 'DEV-F40218EA-VIP', 720, 0, '2026-04-17 01:50:51'),
(36, 'DEV-1C7533DF-VIP', 720, 0, '2026-04-17 01:50:51'),
(37, 'DEV-2EB64471-VIP', 720, 0, '2026-04-17 01:50:51'),
(38, 'DEV-8FACED28-VIP', 720, 0, '2026-04-17 01:50:51'),
(39, 'DEV-E29F1F8E-VIP', 720, 0, '2026-04-17 01:50:51'),
(40, 'DEV-D99B8B0C-VIP', 720, 0, '2026-04-17 01:50:51'),
(41, 'DEV-1852DADE-VIP', 720, 0, '2026-04-17 01:50:51'),
(42, 'DEV-236CE2A3-VIP', 720, 1, '2026-04-17 01:50:51'),
(43, 'DEV-D46A9958-VIP', 720, 0, '2026-04-17 01:50:51'),
(44, 'DEV-2AF9C9CE-VIP', 720, 0, '2026-04-17 01:50:51'),
(45, 'DEV-996DA219-VIP', 720, 1, '2026-04-17 01:50:51'),
(46, 'DEV-A22AE3F2-VIP', 720, 1, '2026-04-17 01:50:51'),
(47, 'DEV-D492DB3B-VIP', 720, 1, '2026-04-17 01:50:51'),
(48, 'DEV-6F462FE7-VIP', 720, 1, '2026-04-17 01:50:51'),
(49, 'DEV-B907378E-VIP', 720, 1, '2026-04-17 01:50:51'),
(51, 'DEV-A6D1F3E1-VIP', 720, 1, '2026-04-17 02:10:14'),
(52, 'DEV-32CADF8E-VIP', 24, 1, '2026-04-17 09:32:22'),
(54, 'DEV-6AAA3ACD-VIP', 720, 1, '2026-04-19 19:15:43'),
(55, 'DEV-544FF1CF-VIP', 24, 0, '2026-04-20 01:00:20');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `image` varchar(255) DEFAULT '',
  `type` varchar(10) DEFAULT 'FREE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `link`, `image`, `type`) VALUES
(4, 'botnet', 'https://vlxx.com', 'uploads/1776469205_IMG_4148.jpeg', 'VIP');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `site_config`
--

CREATE TABLE `site_config` (
  `config_key` varchar(50) NOT NULL,
  `config_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `site_config`
--

INSERT INTO `site_config` (`config_key`, `config_value`) VALUES
('banner_desc', 'Hệ thống cung cấp Tool & Automation , The website provides various tools, including malware.'),
('banner_title', 'DEVNVIOS'),
('chao_khach', 'Chào mừng!'),
('footer_made_by', 'DEVNVIOS'),
('footer_year', '@2024'),
('link_bypass', 'https://vlxx.com/'),
('link_tele_group', 'https://t.me/crackpythonva'),
('logo_text', 'Devnvios.Io.Vn'),
('site_avatar', 'uploads/avatar_site.png'),
('text_key_free', 'DANH SÁCH KEY FREE'),
('text_key_vip', 'DANH SÁCH KEY VIP'),
('text_kich_hoat', 'KÍCH HOẠT NGAY'),
('text_xem_them', 'BẤM XEM THÊM'),
('xin_chao', 'Xin chào,');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(1) DEFAULT '0',
  `key_type` varchar(10) DEFAULT 'NONE',
  `expiry_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `key_type`, `expiry_date`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1, 'NONE', NULL),
(2, 'bzjz', 'mUnfuz-cystut-tobmu8', 1, 'FREE', '2026-04-21 08:42:58'),
(3, 'hihi', 'sydwoz-jarpe7-soJxah', 0, 'NONE', NULL),
(4, 'c', 'devnvios', 0, 'NONE', NULL),
(5, 'tinophan3108', '1234567890cc', 0, 'NONE', NULL),
(6, 'Dat2k2', '42996140a', 0, 'NONE', NULL),
(7, 'skibididomdom123', 'hack678@@@', 0, 'NONE', NULL),
(8, 'tuananh09', 'Zinhdz@99', 0, 'NONE', NULL),
(9, 'cutcutcut0', 'Lopanhem', 0, 'NONE', NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `keys_free`
--
ALTER TABLE `keys_free`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `keys_vip`
--
ALTER TABLE `keys_vip`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `site_config`
--
ALTER TABLE `site_config`
  ADD PRIMARY KEY (`config_key`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `keys_free`
--
ALTER TABLE `keys_free`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT cho bảng `keys_vip`
--
ALTER TABLE `keys_vip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
