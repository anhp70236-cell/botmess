<?php 
include 'db.php'; 
session_start(); 

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $turnstile_response = $_POST['cf-turnstile-response'] ?? '';
    $secret_key = '0x4AAAAAAC_04D54Rq3qaBMtXE6ygMDRUSs';

    $verify_url = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    $data = ['secret' => $secret_key, 'response' => $turnstile_response, 'remoteip' => $_SERVER['REMOTE_ADDR']];
    $options = ['http' => ['header' => "Content-type: application/x-www-form-urlencoded\r\n", 'method' => 'POST', 'content' => http_build_query($data)]];
    $context  = stream_context_create($options);
    $response = file_get_contents($verify_url, false, $context);
    $response_keys = json_decode($response, true);

    if (intval($response_keys["success"]) !== 1) {
        $msg = "Vui lòng hoàn thành xác minh Captcha!";
    } else {
        $user = mysqli_real_escape_string($conn, $_POST['username']);
        $pass = $_POST['password'];
        $repass = $_POST['repassword'];

        if(strlen($user) < 6) {
            $msg = "Tài khoản phải từ 6 ký tự trở lên!";
        } elseif($pass !== $repass) {
            $msg = "Xác nhận mật khẩu không đúng!";
        } else {
            $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$user'");
            if(mysqli_num_rows($check) > 0) {
                $msg = "Tên tài khoản này đã có người dùng!";
            } else {
                $sql = "INSERT INTO users (username, password) VALUES ('$user', '$pass')";
                if(mysqli_query($conn, $sql)) {
                    $_SESSION['username'] = $user;
                    header("Location: index.php?status=success_reg");
                    exit();
                } else { $msg = "Lỗi hệ thống!"; }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    <style>
        * { box-sizing: border-box; }
        body { background: #f8fafc; font-family: sans-serif; -webkit-tap-highlight-color: transparent; min-height: 100dvh; display: flex; flex-direction: column; margin: 0; }
        
        .header-top { 
            background: #1a2b3c; height: 50px; padding: 0 15px; position: fixed; top: 0; width: 100%; z-index: 1001; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1); transition: transform 0.4s; 
        }
        .header-hidden { transform: translateY(-100%); }

        .logo-custom { 
            font-size: 19px; 
            font-weight: 900; 
            color: #3498db; 
            text-decoration: none;
            display: inline-block; 
            letter-spacing: -0.5px; 
            cursor: pointer; 
            line-height: 1;
            transform: skewX(-6deg);
        }

        #menu-content { 
            max-height: 0; overflow: hidden; opacity: 0; 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
            position: absolute; right: 10px; top: 50px; background: white; border-radius: 8px; width: 220px; 
            z-index: 9999; border: 1px solid #eee; box-shadow: 0 10px 25px rgba(0,0,0,0.2); visibility: hidden;
            transform: translateY(-20px); 
        }
        #menu-content.show { max-height: 100px; opacity: 1; padding: 15px; visibility: visible; transform: translateY(0); }
        .menu-text { font-size: 10px; font-weight: bold; text-transform: uppercase; color: #ef4444; text-align: center; }

        #menu-overlay { 
            position: fixed; inset: 0; background: rgba(0,0,0,0.05); z-index: 999; 
            opacity: 0; visibility: hidden; transition: all 0.3s ease; 
        }
        #menu-overlay.show { opacity: 1; visibility: visible; }

        /* ĐÃ FIX LỖI CUỘN Ở ĐÂY: Đổi align-items thành flex-start và thêm padding trên/dưới */
        .main-container { flex: 1; display: flex; align-items: flex-start; justify-content: center; padding: 80px 20px 40px 20px; overflow-y: auto; }
        .card-ios { background: #fff; border-radius: 12px; padding: 25px; width: 100%; max-width: 320px; border: 1px solid #e2e8f0; margin: auto; }
        
        .input-custom { border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px; width: 100%; margin-top: 4px; margin-bottom: 10px; outline: none; font-size: 16px; }
        .btn-act { background: #3b82f6; color: white; font-weight: bold; padding: 10px; border-radius: 6px; width: 100%; text-transform: uppercase; cursor: pointer; border: none; font-size: 13px; }
        
        #strength-bar { height: 3px; width: 100%; background: #f1f5f9; border-radius: 2px; margin-bottom: 8px; overflow: hidden; }
        #strength-fill { height: 100%; width: 0%; transition: 0.4s; }
        
        .heart-beat { color: #ef4444; animation: beat 0.5s infinite; display: inline-block; font-size: 12px; }
        @keyframes beat { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.4); } }

        .turnstile-box { display: flex; justify-content: center; margin-bottom: 10px; transform: scale(0.85); transform-origin: center; width: 100%; }
    </style>
</head>
<body>
    <div id="menu-overlay" onclick="closeMenu()"></div>

    <header id="main-header" class="header-top flex justify-between items-center text-white">
        <div onclick="location.href='index.php'" class="logo-custom">Devnvios.Io.Vn</div>
        <button id="menu-btn" onclick="toggleMenu(event)" class="text-xl p-1 focus:outline-none flex items-center justify-center h-full"><i class="fas fa-bars"></i></button>
        <div id="menu-content">
            <div class="menu-text">Đăng ký để xem<br>danh sách tool</div>
        </div>
    </header>

    <main class="main-container">
        <div class="w-full max-w-[320px] m-auto">
            <?php if($msg !== ""): ?>
                <div id="status-alert" class="p-3 bg-red-50 text-red-600 rounded mb-4 text-center font-bold text-[11px] border border-red-100"><?php echo $msg; ?></div>
            <?php endif; ?>
            <div class="card-ios">
                <h2 class="text-lg font-black text-center text-blue-600 mb-6 uppercase italic tracking-tighter">Register</h2>
                <form method="POST">
                    <label class="text-gray-400 font-bold text-[10px] uppercase ml-1">Tài khoản</label>
                    <input type="text" name="username" class="input-custom" placeholder="Tên tài khoản..." required minlength="6">
                    <label class="text-gray-400 font-bold text-[10px] uppercase ml-1">Mật khẩu</label>
                    <input type="password" name="password" class="input-custom" placeholder="Mật khẩu..." required oninput="checkStrength(this.value)">
                    <div id="strength-bar"><div id="strength-fill"></div></div>
                    <div id="strength-text" class="text-[9px] font-bold uppercase mb-3 ml-1 text-gray-400 italic">Mức độ: Trống</div>
                    <label class="text-gray-400 font-bold text-[10px] uppercase ml-1">Nhập lại mật khẩu</label>
                    <input type="password" name="repassword" class="input-custom" placeholder="Nhập lại mật khẩu..." required>
                    
                    <div class="turnstile-box">
                        <div class="cf-turnstile" data-sitekey="0x4AAAAAAC_04NP8OvQYqZNV" data-theme="light"></div>
                    </div>

                    <button type="submit" class="btn-act mt-2">Đăng Ký</button>
                </form>
                <p class="text-center mt-6 text-[10px] text-gray-400 font-bold uppercase">Đã có tài khoản? <a href="login.php" class="text-blue-500 underline">Đăng Nhập</a></p>
            </div>
        </div>
    </main>

    <footer class="py-4 text-center bg-white border-t mt-auto">
        <div class="uppercase font-bold text-gray-500 text-[11px]">
            MADE WITH <span class="heart-beat"><i class="fas fa-heart"></i></span> BY <a href="https://devnvios.io.vn" class="text-blue-500 hover:underline">DEVNVIOS</a>
            <span class="block text-[10px] text-gray-400 font-normal mt-0.5">@2024</span>
        </div>
    </footer>

    <script>
        const menuContent = document.getElementById('menu-content');
        const menuOverlay = document.getElementById('menu-overlay');

        function toggleMenu(e) { 
            e.stopPropagation(); 
            if(menuContent.classList.contains('show')) closeMenu();
            else openMenu();
        }
        function openMenu() { menuContent.classList.add('show'); menuOverlay.classList.add('show'); }
        function closeMenu() { menuContent.classList.remove('show'); menuOverlay.classList.remove('show'); }

        window.addEventListener('scroll', () => { if(menuContent.classList.contains('show')) closeMenu(); }, { passive: true });

        function checkStrength(p) {
            let fill = document.getElementById('strength-fill');
            let txt = document.getElementById('strength-text');
            if(p.length === 0) { fill.style.width = '0%'; txt.innerText = "Mức độ: Trống"; return; }
            if(p.length < 6) { fill.style.width = '30%'; fill.style.backgroundColor = '#ef4444'; txt.innerText = "Mức độ: Yếu"; txt.style.color = '#ef4444'; }
            else if(p.length < 10) { fill.style.width = '60%'; fill.style.backgroundColor = '#f59e0b'; txt.innerText = "Mức độ: Vừa"; txt.style.color = '#f59e0b'; }
            else { fill.style.width = '100%'; fill.style.backgroundColor = '#22c55e'; txt.innerText = "Mức độ: Mạnh"; txt.style.color = '#22c55e'; }
        }

        setTimeout(() => {
            const alertBox = document.getElementById('status-alert');
            if(alertBox) {
                alertBox.style.transition = "all 0.5s cubic-bezier(0.4, 0, 0.2, 1)";
                alertBox.style.opacity = "0";
                alertBox.style.transform = "translateY(-10px) scale(0.95)";
                setTimeout(() => alertBox.style.display = "none", 500);
            }
        }, 3000);
    </script>
</body>
</html>
